'''
Copyright © 2019 IBM. This notebook and its source code are released under
the terms of the MIT License.
'''

from setuptools import setup

setup(
    name='sklearn_sarima',
    version='0.1',
    description='just sample only',
    url='https://github.ibm.com/NGP-TWC/repository/',
    author='IBM',
    author_email='ibm@ibm.com',
    license='IBM',
    packages=[
        'sklearn_sarima'
    ],
    install_requires=[
        'numpy',
        'pandas',
        'sklearn',
        'statsmodels'
    ],
    zip_safe=False
)
